package programs;

public class Account {
	public double balance;
	public double interestRate;
	
	public Account() {
		balance = 0;
		interestRate = 15.5;
	}
	
	public void deposit(double depositAmount) {
		if (depositAmount > 0) {
			balance += depositAmount;
		}
	}
	public void addInterest() {
		balance *= (1+(interestRate/100));
		
	}
	public String toString() {
		return "Your balance: " + balance;
	}
	
	public static void main(String[] args) {
		Account Marius = new Account();
		Marius.deposit(50.0);
		Marius.addInterest();
		System.out.println(Marius);
	}
}
