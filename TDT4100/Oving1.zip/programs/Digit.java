package programs;

public class Digit {
	public int ns;
	public int value;
	
	public Digit(int ns) {
		this.ns = ns;
		value = 0;
	}
	public int getValue() {
		return value;
	}
	public boolean increment() {
		value++;
		if (value == ns) {
			value = 0;
			return true;
		} else {
			return false;
		}
	}
	public String toString() {
		if (value <10) {
			return value+"";
		} else {
			return Character.toString((char)(value+55));
		}
	}
	public static void main(String[] args) {
		Digit Digit = new Digit(16);
		while (Digit.value <11) {
			System.out.println(Digit);
			Digit.increment();
		}
		System.out.println(Digit);
	}
}
