package programs;

public class LineEditor {
	public String text = "";
	public int insertionIndex;
	
	public LineEditor(String text, int insertionIndex) {
		this.text = text;
		this.insertionIndex = insertionIndex;
	}
	public LineEditor() {
		
	}
	public void left() {
		if (insertionIndex > 0) {
			insertionIndex--;
		}
	}
	public void right() {
		if (insertionIndex < text.length()) {
			insertionIndex++;
		}
	}
	public void insertString(String s) {
		text = text.substring(0,insertionIndex)+ s + text.substring(insertionIndex);
		insertionIndex += s.length();
		
	}
	public void deleteLeft() {
		if (insertionIndex > 0) {
			text = text.substring(0,insertionIndex-1)+text.substring(insertionIndex);
			insertionIndex--;
		}
	}
	public void deleteRight() {
		if (insertionIndex < text.length()) {
			text = text.substring(0,insertionIndex) + text.substring(insertionIndex+1);
		}
	}
}
