package programs;

public class Location {
	public static int x;
	public static int y;
	
	public Location() {
		x = 0;
		y = 0;
	}
	
	public void up() {
		y--;
	}
	public void down() {
		y++;
	}
	public void left() {
		x--;
	}
	public void right() {
		x++;
	}
	public String toString() {
		return "x: " + x + "\ny: " + y+"\n";
	}
	
	public static void main(String[] args) {
		Location figur1 = new Location();
		System.out.println(figur1);
		while (x < 2) {
			figur1.right();
		}
		while (y < 3) {
			figur1.down();
		}
		System.out.println(figur1);
	}
}
