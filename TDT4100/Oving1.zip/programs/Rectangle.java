package programs;

public class Rectangle {
	

}
