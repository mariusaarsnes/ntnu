package programs;

public class UpOrDownCounter {
	int end;
	int counter;
	public UpOrDownCounter( int start, int end) throws IllegalArgumentException {
		if (start == end) {
			throw new IllegalArgumentException("Start and end value cannot be the same");
		}
		this.counter = start;
		this.end = end;
	}
	
	public int getCounter() {
		return counter;
	}
	
	public boolean count() {
		if (counter > end) {
			counter --;
		} else if (counter < end){
			counter++;
		}
		return counter != end;
	}
	
}
