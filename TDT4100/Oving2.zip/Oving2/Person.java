package Oving2;
import java.util.Date;
public class Person {
	String name;
	String eMail;
	Date bDay;
	char gender ='\0' ;
	
	
	private boolean isValidName(String name) throws IllegalArgumentException {
		String[] nameArray = name.split(" ");
		if (!(nameArray.length == 2)) {
			return false;
		} else if(nameArray[0].length() < 2 || nameArray[1].length() < 2) {
			return false;
		}
		
		for (int i = 0;i < name.length(); i++) {
			char c = name.charAt(i);
			if (!(Character.isLetter(c) || c == ' ')) {
				return false;
			}
		}
		return true;
	}
	
	public void setName(String name) throws IllegalArgumentException {
		if (isValidName(name)) {
			this.name = name;
		} else {
			throw new IllegalArgumentException("The name must contain at least two characters,"
					+ " and can conly contain letters or space.");
		}
	}
	public void setEmail(String eMail) throws IllegalArgumentException, IllegalStateException {
		if (!name.isEmpty()) {
			String[] nameArray = name.split(" ");
			
			// Hvis navnet i mailen ikke matcher navnet til objektet
			if (!(nameArray[0].toUpperCase().equals(eMail.substring(0,nameArray[0].length()).toUpperCase()) 
					&& nameArray[1].toUpperCase().equals(eMail.substring(nameArray[0].length()+1,nameArray[1].length()+nameArray[0].length()+1).toUpperCase()))) {
				throw new IllegalStateException("The name in the email isn't the same as the persons name");
			}
			//Hvis navnet ikke etterf�lges av "@":
			if (!(eMail.charAt(name.length()) =='@')) {
				throw new IllegalArgumentException("the character after the name have to be @");
			}
			//Hvis emailen slutter ikke med ".landskode"
			if (!(eMail.charAt(eMail.length()-3) == '.')) {
				throw new IllegalArgumentException("Write a valid email");
			}
			this.eMail = eMail;
		} else {
			throw new IllegalStateException("The email address must begin with the name of the person, separated by a .");
		}
	}
	public void setBirthday(Date bDay) throws IllegalArgumentException {
		Date today = new Date();
		if (today.after(bDay)) {
			this.bDay = bDay;
		} else {
			throw new IllegalArgumentException("The date of birth has to be before today.");
		}
	}
	public void setGender(char gender) throws IllegalArgumentException{
		if ( gender == 'M' || gender == 'F' || gender == '\0') {
			this.gender = gender;
		} else {
			throw new IllegalArgumentException("The gender must be either 'M' or 'F'");
		}
	}
	public String getName(){
		return this.name;
	}
	public String getEmail() {
		return this.eMail;
	}
	public Date getBirthday() {
		return this.bDay;
	}
	public char getGender() {
		return this.gender;
	}
	
	public static void main(String args[]) {
		
		
	}
}
