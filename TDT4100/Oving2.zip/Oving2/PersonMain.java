package Oving2;

public class PersonMain {
	
	Person Ola;
	void init() {
		Ola = new Person();
	}
	void run() {
		Ola.setName("Ola Nordmann");
		Ola.setEmail("ola.nordmann@ntnu.no");
		System.out.println(Ola.getEmail());
		
	}
	public static void main(String[] args) {
		PersonMain program = new PersonMain();
		program.init();
		program.run();
	}

}
