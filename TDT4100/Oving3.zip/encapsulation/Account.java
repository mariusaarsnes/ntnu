package encapsulation;

public class Account {
	private double balance;
	private double interestRate;
	
	
	private boolean isValidValue(double value) {
		if (value < 0) {
			return false;
		}
		return true;
	}
	
	public Account(double balance, double interestRate) throws IllegalArgumentException {
		if (!(isValidValue(balance))) {
			throw new IllegalArgumentException("Balance has to be a postitive, numerical, value");
		}
		if (!(isValidValue(interestRate))){
			throw new IllegalArgumentException("Insterest rate has to be a positive, numerical, value");
		}
		this.balance = balance;
		this.interestRate = interestRate;
	}
	public double getBalance() {
		return this.balance;
	}
	public double getInterestRate() {
		return this.interestRate;
	}
	public void setInterestRate(double interestRate) throws IllegalArgumentException {
		if (!(isValidValue(interestRate))) {
			throw new IllegalArgumentException("Interest rate has to be a positive number");
		}
		this.interestRate = interestRate;
	}
	public void deposit(double depositValue) throws IllegalArgumentException {
		if(!(isValidValue(depositValue))) {
			throw new IllegalArgumentException("The deposited value has to be a positive number.");
		}
		this.balance += depositValue;
	}
	public void withdraw(double withdrawValue) throws IllegalArgumentException, IllegalStateException {
		if(!(isValidValue(withdrawValue))) {
			throw new IllegalArgumentException("The withdrawal value has to be a positive number.");
		}
		if (balance < withdrawValue) {
			throw new IllegalStateException("The withdrawal value has to be less or the same as the balance.");
		}
		this.balance -= withdrawValue;
	}
}
