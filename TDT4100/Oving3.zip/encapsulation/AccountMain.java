package encapsulation;

import java.util.Scanner;

public class AccountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("What is your balance");
		double balance = scanner.nextDouble();
		System.out.println("What is your interest rate?");
		double interestRate = scanner.nextDouble();
		Account account = new Account(balance, interestRate);
		
		boolean keepRunning = true;
		while (keepRunning) {
			System.out.println("What do you want to do?\n"
								+ "1: Get balance.\n"
								+ "2: Get interest rate.\n"
								+ "3: Set interest rate. \n"
								+ "4: Deposit money.\n"
								+ "5: Withdraw money.\n");
			int choice = scanner.nextInt();
			switch(choice) {
			case 1: 
				System.out.println(account.getBalance() + "\n\n");
				break;
			case 2: 
				System.out.println(account.getInterestRate() + "\n\n");
				break;
			case 3:
				System.out.println("Write in the new interest rate.");
				interestRate = scanner.nextDouble();
				account.setInterestRate(interestRate);
				System.out.println("\n\n");
				break;
			case 4:
				System.out.println("How much are you depositing?");
				double depositValue = scanner.nextDouble();
				account.deposit(depositValue);
				System.out.println("\n\n");
				break;
			case 5:
				System.out.println("How much do you want to withdraw?");
				double withdrawValue = scanner.nextDouble();
				account.withdraw(withdrawValue);
				System.out.println("\n\n");
				break;
			default:
				keepRunning = false;
			}
			
		}
		scanner.close();
	}

}
