package encapsulation;

public class Nim {
	private int pile0Size;
	private int pile1Size;
	private int pile2Size;
	
	private boolean isValidPileSize(int value) {
		if (value < 0) {
			return false;
		}
		return true;
	}
	public boolean isGameOver() {
		if (pile0Size == 0 || pile1Size == 0 || pile2Size == 0) {
			return true;
		}
		return false;
	}
	public boolean isValidMove(int number, int targetPile) {
		boolean result = true;
		if (number < 1 || (targetPile > 2 && targetPile < 0) || isGameOver()) {
			result = false;
		}else if (targetPile == 0 && number > pile0Size) {
			result = false;
		}else if (targetPile == 1 && number > pile1Size) {
			result = false;
		}else if (targetPile == 2 && number > pile2Size) {
			result = false;
		}
		
		return result;
	}
	public Nim(int pileSize) {
		if (isValidPileSize(pileSize)) {
			this.pile0Size = pileSize;
			this.pile1Size = pileSize;
			this.pile2Size = pileSize;
		}
	}
	public Nim() {
		this.pile0Size = 10;
		this.pile1Size = 10;
		this.pile2Size = 10;
	}
	
	public void removePieces(int number, int targetPile) throws IllegalArgumentException, IllegalStateException {
		if (isGameOver()) {
			throw new IllegalStateException("The game is over!");
		}
		if (!(isValidMove(number, targetPile))) {
			throw new IllegalArgumentException("That move is not legal!");
		}
		if (targetPile == 0) {
			pile0Size -= number;
		} else if(targetPile == 1) {
			pile1Size -= number;
		} else if(targetPile == 2) {
			pile2Size -= number;
		}
	}
	public int getPile(int targetPile) throws IllegalArgumentException{
		if (targetPile == 0) {
			return pile0Size;
		} else if(targetPile == 1) {
			return pile1Size;
		} else if(targetPile == 2) {
			return pile2Size;
		} else {
			throw new IllegalArgumentException("That is not a valid pile-ID");
		}
	}
	@Override
	public String toString() {
		return String.format("pile0: %s, pile1: %s, pile2: %s", pile0Size, pile1Size, pile2Size);
	}
}
