package encapsulation;

import java.util.Scanner;

public class NimProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("How big are the stacks going to be?");
		int sCount = scanner.nextInt();
		Nim nim = new Nim(sCount);
		System.out.println(nim);
		while(!(nim.isGameOver())) {
			System.out.println("How many sticks do you want to remove?");
			sCount = scanner.nextInt();
			System.out.println("Which pile do you choose?");
			int pile = scanner.nextInt();
			nim.removePieces(sCount, pile);
			System.out.println(nim);
		}
		scanner.close();
		System.out.println("gameover!");
		
	}

}
