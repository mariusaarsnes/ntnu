package Oving4;
import java.util.Random;
public class sudokuBrett {
	
	private String[] boards = {
	                          ".....2..38.273.45....6..87.9.8..5367..6...1..4513..9.8.84..3....79.512.62..8.....",
	                          ".68.257.3..........71..39..61.35.2...8.....4...3.64.95..76..58..........8.653.42.",
	                          ".....59.4.8..9.6.5..6....3..3.7.145...8.4.7...742.6.9..6....3..8.1.6..7.3.98.....",
	                          "...6...513....2..66...3..89..4.2.6...3.418.2...8.7.1..59..6...38..3....241...9..."
	                          };
	
	private sudokuRute[][] playBoard;
	private int chosenBoard;
	
	public sudokuBrett() {
		Random generator = new Random();
		this.chosenBoard = generator.nextInt(4);
		
		buildBoard(boards[chosenBoard]);
	}
	public sudokuBrett(String chosenBoard) {
		if (chosenBoard.length() != 81) {
			System.out.println("The board isn't of correct length.");
			return;
		}
		if (containsIllegalValues(chosenBoard)) {
			System.out.println("The board contains illegal values.");
			return;
		}
		buildBoard(chosenBoard);
	}
	
	private boolean containsIllegalValues(String stringBoard) {
		for (int i = 0; i< stringBoard.length(); i++) {
			if (!(".0123456789".indexOf(stringBoard.charAt(i)) >= 0)) {
				return true;
			}
		}
		return false;
	}
	
	private void buildBoard(String values) {
		playBoard = new sudokuRute[9][9];
		int k = 0;
		int b1 = 0;
		for (int i = 0; i<9; i++) {
			int b2 = 0;
			if (i == 3 || i == 6) {
				b1 += 3;
			}
			for (int j = 0;j < 9; j++) {
				if (j  == 3 || j == 6) {
					b2 += 1;
				}
				playBoard[i][j] = new sudokuRute(values.charAt(k),b1+b2);
				k++;
			}
		}
	}
	
	private void removeDuplicateMark() {
		for (int i = 0; i<9; i++) {
			for (int j = 0; j<9; j++) {
				if (playBoard[i][j].isChangeAble()) {
					playBoard[i][j].setRight(' ');
				}
			}
		}
	}
	private void checkDuplicateRow(int row) {
		for (int i = 0; i< 8; i++) {
			for (int j = i+1; j<9;j++) {
				if (playBoard[row][i].getValue() == playBoard[row][j].getValue()) {
					if (playBoard[row][i].isChangeAble() 
							&& playBoard[row][i].getValue() != '.') {
						playBoard[row][i].setRight('*');
					}
					if (playBoard[row][j].isChangeAble() && 
							playBoard[row][j].getValue() != '.') {
						playBoard[row][j].setRight('*');
					}
				}
			}
		}
	}
	private void checkDuplicateColumn(int column) {
		for (int i = 0; i< 8; i++) {
			for (int j = i+1; j<9;j++) {
				if (playBoard[i][column].getValue() == playBoard[j][column].getValue()) {
					if (playBoard[i][column].isChangeAble() 
							&& playBoard[i][column].getValue() != '.') {
						playBoard[i][column].setRight('*');
					}
					if (playBoard[j][column].isChangeAble() && 
							playBoard[j][column].getValue() != '.') {
						playBoard[j][column].setRight('*');
					}
				}
			}
		}
	}
	private void checkDuplicateBox(sudokuRute[] box) {
		for (int i = 0; i < 8; i++) {
			for ( int j = i+1; j < 9; j++) {
				if (box[i].getValue() == box[j].getValue()) {
					if (box[i].isChangeAble() 
							&& box[i].getValue() != '.') {
						box[i].setRight('*');
					}
					if (box[j].isChangeAble() && 
							box[j].getValue() != '.') {
						box[j].setRight('*');
					}
					
				}
			}
		}
	}
	
	private void checkDuplicate() {
		removeDuplicateMark();
		for (int i = 0; i <9; i++) {
			checkDuplicateRow(i);
			checkDuplicateColumn(i);
		}
		
		sudokuRute[] listSameBox = new sudokuRute[9];
		int k = 0;
		int box = 0;
		while (box < 6) {
			k = 0;
			for (int i = 0; i < 9; i++) {
				for (int j = 0; j < 9; j++) {
					if (playBoard[i][j].getBox() == box ) {
						listSameBox[k] = playBoard[i][j];
						k++;
					}
				}
			}
			checkDuplicateBox(listSameBox);
			box++;
		}
		
	}
	
	public void changeBlock(String input) {
		int row;
		int column;
		char value;
		if (input.length() != 3) {
			System.out.println("Your input is not valid."
					+ "Input format: <row(0-8)><column(0-8)><value(1-9)>");
			return;
		}
		try {
			// Check if it is a number, by trying to convert it into an int
			row = Integer.valueOf(input.charAt(0))-48;
			column = Integer.valueOf(input.charAt(1))-48;
			int tempValue = Integer.valueOf(input.charAt(2))-48;
			value = (char) input.charAt(2);
		} catch(NumberFormatException nfe) {
			System.out.println("Your input has to be three digits."
					+ "Input format: <row(0-8)><column(0-8)><value(1-9)>");
			return;
		}
		if ((row >= 0 && row <9 )&& (column >= 0 && column < 9) && 
				".0123456789".indexOf(value) >= 0) {
			playBoard[row][column].setValue(value);
			checkDuplicate();
			
		} else {
			System.out.println("Your input is invalid.\n"
					+ "Input format: <row(0-8)><column(0-8)><value(1-9)>");
		}
	}
	
	public boolean isGameOver() {
		for (int i= 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				if (playBoard[i][j].getValue() == '.') {
					return false;
				}
				if (playBoard[i][j].getRight() == '*') {
					return false;
				}
			}
		}
		return true;
	}
	
	public sudokuRute[][] getBoard() {
		return playBoard;
	}
	public String toString() {
		String utskrift = "";
		utskrift += ("     1   2   3     4   5   6     7   8   9\n");
		utskrift += ("  +-------------+-------------+-------------+\n");
		for (int i = 0; i < 9; i++) {
			utskrift += (i+1 + " | ");
			for (int j = 0; j < 9; j++) {
				if ( j== 0) {
					utskrift += playBoard[i][j].getLeft();
				} else {
					utskrift += " " +  playBoard[i][j].getLeft();
				}
				utskrift += playBoard[i][j].getValue();
				if (j == 2 || j == 5) {
					utskrift += playBoard[i][j].getRight() + " |";
				} else {
					utskrift += playBoard[i][j].getRight();
				}
			}
			utskrift += " |\n";
			if(i == 2 || i == 5) {
				utskrift += "  +-------------+-------------+-------------+\n";
			}
		}
		utskrift += ("  +-------------+-------------+-------------+");
		return utskrift;
	}
}
