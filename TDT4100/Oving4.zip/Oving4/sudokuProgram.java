package Oving4;
import java.util.Scanner;

public class sudokuProgram {
	sudokuBrett board;
	Scanner scanner;
	String input;
	int row;
	int column;
	char value;
	boolean isEmpty = true;
	
	
	public void init() {
		scanner = new Scanner(System.in);
		
		System.out.println("PLAY SUDOKU!");
		System.out.println("Input format: <row(0-8)><column(0-8)><value(1-9)>\n"
							+ "First, write 'random' for randomly chosen board,\n"
							+ "or a number between 0 and 3 to pick a spesific one.");
		while (true) {
			System.out.print("> ");
			input = scanner.nextLine();
			
			if (input.toUpperCase().equals("RANDOM")) {
				board = new sudokuBrett();
			} else {
				board = new sudokuBrett(input);
			}
			if(!isEmpty()) {
				break;
			}
			
		}
		System.out.println(board);
	}
	public void run() {
		while (true) {
			System.out.print("> ");
			input = scanner.nextLine();
			board.changeBlock(input);
			System.out.println(board);
			if (board.isGameOver()) {
				System.out.println("WOHO! You WIN.\nGZ mate.");
				return;
			}
		}
	}
	private boolean isEmpty() {
		return (board.getBoard() == null);
	}
	public static void main(String[] args) {
		sudokuProgram program = new sudokuProgram();
		program.init();
		program.run();
		
	}

}
