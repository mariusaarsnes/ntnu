package Oving5;

public class Card {
	private char suit;
	private int face;
	
	public Card(char suit , int face) throws IllegalArgumentException {
		if(!isValidType(suit)) {
			throw new IllegalArgumentException("That is not a valid type.");
		}
		if (!isValidValue(face)) {
			throw new IllegalArgumentException("That is not a valid value.");
		}
		this.suit = suit;
		this.face = face;
	}
	
	private boolean isValidType(char suit) {
		if ("SHDC".indexOf(suit) >= 0) {
			return true;
		}
		return false;
	}
	private boolean isValidValue(int face) {
		if(face < 1 || face > 13) {
			return false;
		}
		return true;
	}

	public char getSuit() {
		return this.suit;
	}
	public int getFace() {
		return this.face;
	}
	
	@Override
	public String toString() {
		return "" + suit + face;
	}

}
