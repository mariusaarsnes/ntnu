package Oving5;

import java.util.ArrayList;

public class CardDeck {
	
	private ArrayList<Card> deck;
	
	public CardDeck(int n) {
		char suit;
		deck = new ArrayList<Card>();
		for (int i= 0; i<4; i++) {
			switch (i) {
			case 0: 
				suit = 'S';
				break;
			case 1:
				suit = 'H';
				break;
			case 2:
				suit = 'D';
				break;
			default:
				suit = 'C';
				break;
			}
			for(int j = 0; j<n; j++) {
				deck.add(new Card(suit,j+1));
			}
		}
	}
	
	public int getCardCount() {
		return deck.size();
	}
	public Card getCard(int n) throws IllegalArgumentException {
		if (n < 0 || n >= deck.size()) {
			throw new IllegalArgumentException("There is no card "
					+ "in that position");
		}
		return deck.get(n);
	}
	
	public void deal(CardHand hand, int n) {
		for(int i = 0; i<n;i++) {
			hand.addCard(deck.get(deck.size()-1));
			deck.remove(deck.size()-1);
		}
	}
	
	public void shufflePerfectly() {
		ArrayList<Card> firstHalf = new ArrayList<Card>();
		ArrayList<Card> secondHalf = new ArrayList<Card>();
		
		for (int i = 0; i < deck.size()/2;i++) {
			firstHalf.add(deck.get(i));
			secondHalf.add(deck.get(i+(deck.size()/2)));
		}
		for (int i = 0; i < deck.size(); i++) {
			if (i % 2== 0) {
				deck.set(i,firstHalf.remove(0));
			} else {
				deck.set(i,secondHalf.remove(0));
			}
		}
	}
}
