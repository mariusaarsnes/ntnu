package Oving5;

import java.util.ArrayList;
public class CardHand {
	
	private ArrayList<Card> hand;
	
	public CardHand() {
		hand = new ArrayList<Card>();
	}
	
	public int getCardCount() {
		return hand.size();
	}
	public Card getCard(int n) throws IllegalArgumentException {
		if (n < 0 || n >= hand.size()) {
			throw new IllegalArgumentException("There is no card "
					+ "in that position");
		}
		return hand.get(n);
	}
	
	public void addCard(Card card) {
		this.hand.add(card);
	}
	
	public Card play(int n) throws IllegalStateException {
		if (hand.size() <= 0) {
			throw new IllegalStateException("Your hand is empty");
		}
		Card returnValue = hand.get(n);
		hand.remove(n);
		return returnValue;
	}

}
