package Oving6;

import java.util.Arrays;
import java.util.Iterator;

public class BinaryComputingIteratorProgram {

	public static void main(String[] args) {
		Iterator<Double> iterator1 = Arrays.asList(0.5, -2.0).iterator();
		Iterator<Double> iterator2 = Arrays.asList(5.0).iterator();
		BinaryComputingIterator binaryIterator = new BinaryComputingIterator(iterator1, iterator2, null, 2.0, (x, y) -> x*y);
		
		binaryIterator.next();		// 7.0
		binaryIterator.hasNext();	// true
		binaryIterator.next();		// 13.0
		binaryIterator.hasNext();	// false
		
	}

}
