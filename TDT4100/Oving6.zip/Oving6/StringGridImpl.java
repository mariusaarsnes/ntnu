package Oving6;

import java.util.ArrayList;
import java.util.Iterator;

public class StringGridImpl implements StringGrid {
	
	private ArrayList<ArrayList<String>> grid;
	private int rows;
	private int columnCount;
	
	public StringGridImpl(int rows, int columnCount) {
		grid = new ArrayList<ArrayList<String>>(rows);
		for (int i = 0; i< columnCount; i++){
			grid.add(new ArrayList<String>());
		}
		this.rows = rows;
		this.columnCount = columnCount;
	}

	@Override
	public int getRowCount() {
		return rows;
	}

	@Override
	public int getColumnCount() {
		return columnCount;
	}

	@Override
	public String getElement(int row, int column) {
		if ((row >= 0 && row < rows) && (column >= 0 && column < columnCount)) {
			return grid.get(row).get(column);
		}
		return "";
	}

	@Override
	public void setElement(int row, int column, String element) {
		grid.get(row).add(column,element);	
	}

	@Override
	public Iterator<String> iterator() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
