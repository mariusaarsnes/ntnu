package Oving6;

public class StringGridImplProgram {
	
	public static void main(String[] args) {
		StringGridImpl test = new StringGridImpl(3,3);
		test.setElement(0, 0, "0,0");
		
	}

}

