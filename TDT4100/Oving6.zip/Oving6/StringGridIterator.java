package Oving6;

import java.util.Iterator;

public class StringGridIterator implements Iterator<String> {
	
	
	StringGrid grid;
	boolean rowMajor;
	int row = 0;
	int column = 0;
	
	
	public StringGridIterator(StringGrid grid,boolean rowMajor) {
		this.grid = grid;
		this.rowMajor = rowMajor;
	}

	@Override
	public boolean hasNext() {
		return row < grid.getRowCount() && column < grid.getColumnCount();
	}

	@Override
	public String next() {
		String nextElement = grid.getElement(row, column);
		if (rowMajor) {
			if (column == grid.getColumnCount()-1) {
				column = 0;
				row += 1;
			} else {
				column += 1;
			}
		} else {
			if (row == grid.getRowCount()-1) {
				row = 0;
				column +=1;
			} else {
				row += 1;
			}
		}
		
		return nextElement;
	}
	
	public void remove() throws UnsupportedOperationException {
		throw new UnsupportedOperationException
		("This operation is not supported");
	}
	
}
