package Oving4;

import java.io.IOException;

public interface SudokuGameSaverAndLoader {
	public void save()throws IOException;
	public void load() throws IOException;
}
