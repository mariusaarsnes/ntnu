import pickle
from random import randint
from os import path

tallBrett = None
freda=[]

def meny():
    print("Velkommen til Sudoku!")
    print("velg fra menyen for å komme i gang:")
    print("1. Start nytt spill")
    print("2. Last inn tidligere spill")
    print("3. Avslutt")
    
          
def printBrett(tallBrett):
    print("    0 1 2   3 4 5   6 7 8  ")
    print("  +-------+-------+-------+")
    print("0 |",tallBrett[0][0],tallBrett[0][1],tallBrett[0][2],"|",tallBrett[0][3],tallBrett[0][4],tallBrett[0][5],"|",tallBrett[0][6],tallBrett[0][7],tallBrett[0][8],"|")
    print("1 |",tallBrett[1][0],tallBrett[1][1],tallBrett[1][2],"|",tallBrett[1][3],tallBrett[1][4],tallBrett[1][5],"|",tallBrett[1][6],tallBrett[1][7],tallBrett[1][8],"|")
    print("2 |",tallBrett[2][0],tallBrett[2][1],tallBrett[2][2],"|",tallBrett[2][3],tallBrett[2][4],tallBrett[2][5],"|",tallBrett[2][6],tallBrett[2][7],tallBrett[2][8],"|")
    print("  +-------+-------+-------+")
    print("3 |",tallBrett[3][0],tallBrett[3][1],tallBrett[3][2],"|",tallBrett[3][3],tallBrett[3][4],tallBrett[3][5],"|",tallBrett[3][6],tallBrett[3][7],tallBrett[3][8],"|")
    print("4 |",tallBrett[4][0],tallBrett[4][1],tallBrett[4][2],"|",tallBrett[4][3],tallBrett[4][4],tallBrett[4][5],"|",tallBrett[4][6],tallBrett[4][7],tallBrett[4][8],"|")
    print("5 |",tallBrett[5][0],tallBrett[5][1],tallBrett[5][2],"|",tallBrett[5][3],tallBrett[5][4],tallBrett[5][5],"|",tallBrett[5][6],tallBrett[5][7],tallBrett[5][8],"|")
    print("  +-------+-------+-------+")
    print("6 |",tallBrett[6][0],tallBrett[6][1],tallBrett[6][2],"|",tallBrett[6][3],tallBrett[6][4],tallBrett[6][5],"|",tallBrett[6][6],tallBrett[6][7],tallBrett[6][8],"|")
    print("7 |",tallBrett[7][0],tallBrett[7][1],tallBrett[7][2],"|",tallBrett[7][3],tallBrett[7][4],tallBrett[7][5],"|",tallBrett[7][6],tallBrett[7][7],tallBrett[7][8],"|")
    print("8 |",tallBrett[8][0],tallBrett[8][1],tallBrett[8][2],"|",tallBrett[8][3],tallBrett[8][4],tallBrett[8][5],"|",tallBrett[8][6],tallBrett[8][7],tallBrett[8][8],"|")
    print("  +-------+-------+-------+")

def slett(tallBrett, freda):
    koord = True
    while koord == True:
        plass = input("Skriv inn koordinater for tallet du vil slette(enter for å avbryte): ").lower().strip()
        if plass == "":
            return
        if plass == "lagre":
            save(navn, tallBrett)
            print()
            return
        if plass == "avslutt":
            print()
            print("¤¤¤¤¤¤¤¤  Du blir nå returnert til menyen  ¤¤¤¤¤¤¤¤")
            print()
            main()
            return
        if "," in plass:
            plass.split(',')
            x = int(plass[0])
            y = int(plass[2])
        if "," not in plass and plass != "":
            print ("Du skrev noe ugyldig, prøv igjen!")
            print()
            koord == True
            continue
        if [x,y] in freda:
            print("EY! PLIS ikke juks a!")
            print()
            return
        if (x >= 0 and x <= 8) and (y >= 0 and y <= 8):
            tallBrett[x][y] = 0
            return tallBrett
        elif x <= 0 or x >= 8:
            print("OBS, x-koordinatet du skrev er mindre enn 0 eller større enn 8")
            print("Prøv igjen")
            print()
            koord == True
        elif y <= 0 or y > 8:
            print("OBS, y-koordinatet du skrev er mindre enn 0 eller større enn 8")
            print("Prøv igjen")
            print()
            koord == True
    
def add(tallBrett, freda, navn):
    global slette
    slette = "nei"
    koord = True
    while koord == True:
        plass = input("Skriv inn koordinater for tallet du vil endre(Trykk enter hvis du skal slette): ").lower().strip()
        if plass == "":
            slette = "ja"
            return slette
        if plass == "lagre":
            save(navn, tallBrett)
            return
        if plass == "avslutt":
            print()
            print("¤¤¤¤¤¤¤¤  Du blir nå returnert til menyen  ¤¤¤¤¤¤¤¤")
            print()
            main()
            return
        if "," in plass:
            plass.split(',')
            x = int(plass[0])
            y = int(plass[2])
        if "," not in plass and plass != "":
            print ("Du skrev noe ugyldig, prøv igjen!")
            print()
            add(tallBrett, freda, navn)
        if [x,y] in freda:
            print("EY! PLIS ikke juks a!")
            print()
            add(tallBrett, freda, navn)
        if (x >= 0 and x <= 8) and (y >= 0 and y <= 8):
            koord = False
        elif x <= 0 or x >= 8:
            print("OBS, x-koordinatet du skrev er mindre enn 0 eller større enn 8")
            print("Prøv igjen")
            print()
            koord == True
        elif y <= 0 or y > 8:
            print("OBS, y-koordinatet du skrev er mindre enn 0 eller større enn 8")
            print("Prøv igjen")
            print()
            koord == True
    mengde = True
    while mengde == True:
        z = input("Hva vil du endre tallet til: ").lower().strip()
        if z == "lagre":
            save(navn, tallBrett)
            mengde == False
        if z == "avslutt":
            print()
            main()
            mengde == False
        if z.isdigit() == True:
            if int(z)%1== 0:
                z=int(z)
                if z >= 1 and z <= 9:
                    mengde == False
                    break
                elif z <= 1 or z >= 9:
                    print("OBS, tallet du skrev er mindre enn 1 eller større enn 9")
                    print("Prøv igjen")
                    print()
                    mengde == True
            else:
                print("Her opperer vi kun med heltal, prøv igjen")
            mengde == True
        else:
            print("Det du skrev er ikke gyldig, prøv igjen")
            mengde == True
            
    kolGodkjent = kolSjekk(tallBrett, y, z)
    radGodkjent = radSjekk(tallBrett, x, z)
    boksGodkjent = boksSjekk(tallBrett, x, y, z)
    if kolGodkjent == True and radGodkjent == True and boksGodkjent == True:
        tallBrett[x][y] = z
    elif kolGodkjent == False or boksGodkjent == False or radGodkjent == False:
        print("Du kan ikke skrive dette tallet, det finnes alt i raden, kolonnen eller kvadratet")
        print("Prøv igjen")
        print()
        add(tallBrett, freda, navn)
        
    return tallBrett, slette

def vinne(tallBrett):
    if 0 not in sum(tallBrett,[]):
        print("Grattis, du vant, mor må være stolt nu")
        print()
        return True
    elif 0 in sum(tallBrett,[]):
        return False
    
def spill(tallBrett):
    stop = vinne(tallBrett)
    while stop == False:
        printBrett(tallBrett)
        add(tallBrett, freda, navn)
        if slette == "ja":
            slett(tallBrett, freda)
        if stop == True:
            main()
    
def kolSjekk(tallBrett, y, z):
    kol = []
    for i in range(9):
        kol.append(tallBrett[i][y])
    if z in kol:
        return False 
    elif z not in kol:
        return True

def radSjekk(tallBrett, x, z):
    rad = []
    for i in range(9):
        rad.append(tallBrett[x][i])
    if z in rad:
        return False
    elif z not in rad:
        return True

def boksSjekk(tallBrett, x, y, z):
    boks = []
    if x in range(0,3):
	    start1 = 0
    elif x in range(3,6):
	    start1 = 3
    elif x in range(6,9):
	    start1 = 6

    if y in range(0,3):
	    start2 = 0
    elif y in range(3,6):
	    start2 = 3
    elif y in range(6,9):
	    start2 = 6

    for k in range(start1, start1+3):
	    for h in range(start2, start2+3):
		    boks.append(tallBrett[k][h])
    if z in boks:
        return False   
    elif z not in boks:
        return True
    

    
def main():
    meny()
    print()
    valg = input("Skriv inn valget (tall fra 1-3): ").strip()
    
    if valg == "1":
        print()
        name = True
        while True:
            global navn
            navn = input("Skriv inn navn (NB! spillet vil bli lagret som dette navnet!): ")
            if "spill" in navn:
                print("Spillet kan ikke hete dette")
            elif navn == "avslutt":
                print()
                print("¤¤¤¤¤¤¤¤  Du blir nå returnert til menyen  ¤¤¤¤¤¤¤¤")
                print()
                main()
            elif "spill" not in navn:
                break
            
        nytt_spill()
        save(navn, tallBrett)
        print()

        fredet(tallBrett, freda)
        spill(tallBrett)


    elif valg == "2":
        open_saved()
        fredet(tallBrett, freda)
        spill(tallBrett)

    elif valg == "3":
        print("Hade!")
        returnx
        print("Det du skrev er ikke gyldig")
        print("prøv igjen")
        print()
        main()
        
def fredet(tallBrett,freda):
    if len(freda) == 0:
        for i in range(9):
            for j in range(9):
                if tallBrett[i][j] > 0:
                    freda.append([i,j])
        return freda

def open_saved():
    global tallBrett
    global navn
    navn = input("Skriv inn hva du lagret spillet som: ")
    if navn == "avslutt":
        print()
        print("¤¤¤¤¤¤¤¤  Du blir nå returnert til menyen  ¤¤¤¤¤¤¤¤")
        print()
        main()
                
    file_path = path.relpath = ("savedGames/"+str(navn)+".pickle")
    with open(file_path, "rb") as f:
        tallBrett = pickle.load(f)

def save(navn, tallBrett):
    file_path = path.relpath = ("savedGames/"+str(navn)+".pickle")
    with open(file_path, "wb") as f:
        pickle.dump(tallBrett,f)
        
def nytt_spill():
    tall = randint(1,2)
    file_path = path.relpath = ('maps/spill'+str(tall)+'.pickle')
    with open(file_path, 'rb') as handle:
        global tallBrett
        tallBrett = pickle.load(handle)
main()

