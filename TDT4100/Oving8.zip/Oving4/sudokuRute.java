package Oving4;

public class sudokuRute {
	private char value;
	private boolean changeAble;
	private char left;
	private char right;
	private int box;
	
	private sudokuRute(char value, boolean changeAble, char left, char right, int box) {
		this.value = value;
		this.changeAble = changeAble;
		this.left = left;
		this.right = right;
		this.box = box;
	}
	public sudokuRute(char value, int box) {
		this.value = value;
		this.box = box;
		if (".".indexOf(value) >= 0) {
			this.changeAble = true;
			this.left = ' ';
			this.right =' ';
		} else {
			this.changeAble = false;
			this.left = '(';
			this.right = ')';
		}
		
	}
	
	public boolean isValidValue(char value) {
		if(!("123456789.".indexOf(value) >= 0)) {
			return false;
		}
		return true;
	}
	public boolean isChangeAble() {
		return changeAble;
	}

	public void setValue(char value) {
		if (isValidValue(value) && isChangeAble()) {
			this.value = value;
		}
		else {
			System.out.println("You are not allowed to use that value, "
					+ "or you are not allowed to change that field");
			
		}
	}
	public void setRight(char value) {
		this.right = value;
	}
	public char getValue() {
		return this.value;
	}
	public int getBox() {
		return this.box;
	}
	public char getRight() {
		return this.right;
	}
	public char getLeft() {
		return this.left;
	}
	
	public sudokuRute copy() {
		return new sudokuRute(this.value, 
				this.changeAble, this.left,this.right,this.box);
	}
}
