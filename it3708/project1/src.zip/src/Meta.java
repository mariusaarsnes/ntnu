public class Meta {

    int vehicles;
    int customers;
    int depots;


    public Meta(int m, int n, int t) {
        this.vehicles = m;
        this.customers = n;
        this.depots = t;
    }
}
