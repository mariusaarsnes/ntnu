public class ParticleElement {

    int operation;
    double position;
    double velocity;


    public ParticleElement(int operation, double position, double velocity) {
        this.operation = operation;
        this.position = position;
        this.velocity = velocity;
    }
}
