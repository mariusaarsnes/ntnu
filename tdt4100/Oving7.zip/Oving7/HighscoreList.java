package Oving7;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import Oving7.HighscoreListListener;

public class HighscoreList{
	
	private int maxSize;
	private ArrayList<Integer> results = new ArrayList<>();
	private Collection<HighscoreListListener> listeners = new ArrayList<>();
	
	public HighscoreList(int maxSize) {
		this.maxSize = maxSize;
	}
	
	public int size() {
		return results.size();
	}
	
	public int getElement(int i) throws IllegalArgumentException {
		if (i > results.size() || i < 0) {
			throw new IllegalArgumentException("The list isn't that big");
		}
		Collections.sort(results);
		
		return results.get(i);
	}
	
	public void addResult(int newElement) {
		results.add(newElement);
		boolean changed = false;
		int i = 0, tempValue;
		for (i = results.size()-1; i > 0; i--) {
			if (results.get(i) < results.get(i-1)) {
				tempValue = results.get(i-1);
				results.set(i-1, results.get(i));
				results.set(i, tempValue);
				changed = true;
			} else {
				break;
			}
		}
		
		if (results.size() > maxSize) results.remove(maxSize);
		else changed = true;
		if (changed) {
			for ( HighscoreListListener listener : listeners) {
				listener.listChanged(this, i);
			}
		}
	}
	
	public void addHighscoreListListener(HighscoreListListener newListener) {
		listeners.add(newListener);
	}
	
	public void removeHighscoreListListener(HighscoreListListener removeListener) {
		if (listeners.contains(removeListener)) {
			listeners.remove(removeListener);
		}
	}
}
