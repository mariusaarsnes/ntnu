package Oving7;

public interface HighscoreListListener {
	public void listChanged(HighscoreList list, int i);

}
