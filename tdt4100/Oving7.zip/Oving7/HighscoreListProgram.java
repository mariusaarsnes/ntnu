package Oving7;

public class HighscoreListProgram implements HighscoreListListener{
	
	HighscoreList highscoreList;
	
	public void init() {
		highscoreList = new HighscoreList(5);
	}

	public void run() {
		highscoreList.addHighscoreListListener(this);
		highscoreList.addResult(5);
		highscoreList.addResult(6);
		highscoreList.addResult(2);
		
	}
	
	@Override
	public void listChanged(HighscoreList list, int i) {
		System.out.println("The list has been updated!");
		System.out.println("There is a new entry at position " + (i+1)+ ".");
		for (int index = 0; index < list.size(); index++) {
			System.out.println(index+1 + ": " + list.getElement(index));
		}
		System.out.println("\n\n");
		
	}
	public static void main(String[] args) {
		HighscoreListProgram program = new HighscoreListProgram();
		program.init();
		program.run();
	}
}
