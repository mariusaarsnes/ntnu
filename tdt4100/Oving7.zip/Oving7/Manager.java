package Oving7;

import java.util.Collection;
import java.util.function.BinaryOperator;

public class Manager implements Employee{
	
	Collection<Employee> employees;
	public Manager(Collection<Employee> employees) 
			throws IllegalArgumentException {
		if (employees.isEmpty()) {
			throw new 
			IllegalArgumentException("The list of employees is empty");
		}
		this.employees = employees;
		
	}
	@Override
	public double doCalculations(BinaryOperator<Double> operation, double value1, double value2) {
		return employees.iterator().next().doCalculations(operation, value1, value2);
	}
	@Override
	public void printDocument(String document) {
		employees.iterator().next().printDocument(document);
	}
	@Override
	public int getTaskCount() {
		int taskCount = 0;
		for (Employee employee : employees) {
			taskCount += employee.getTaskCount();
		}
		return taskCount;
	}
	@Override
	public int getResourceCount() {
		int resourceCount = 1;
		for (Employee employee: employees) {
			resourceCount += employee.getResourceCount();
		}
		
		return resourceCount;
	}

}
