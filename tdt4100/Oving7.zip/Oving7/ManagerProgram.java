package Oving7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

public class ManagerProgram {
	public static void main(String[] args) {
		
		Collection<Employee> collectionClerk1 = new ArrayList<>();
		Collection<Employee> collectionClerk2 = new ArrayList<>();
		Collection<Employee> collectionClerk3 = new ArrayList<>();
		
		Collection<Employee> collectionManager1 = new ArrayList<>();
		Collection<Employee> collectionManager2 = new ArrayList<>();
		
		Collection<Employee> collectionManagerTop = new ArrayList<>();
		
		Printer printer = new Printer();
		Clerk clerk1 = new Clerk(printer);
		Clerk clerk2 = new Clerk(printer);
		Clerk clerk3 = new Clerk(printer);
		Clerk clerk4 = new Clerk(printer);
		Clerk clerk5 = new Clerk(printer);
		Clerk clerk6 = new Clerk(printer);
		
		collectionClerk1.addAll(Arrays.asList(clerk1,clerk2));
		collectionClerk2.addAll(Arrays.asList(clerk3,clerk4));
		collectionClerk3.addAll(Arrays.asList(clerk5,clerk6));
		
		Manager managerNederst1 = new Manager(collectionClerk1);
		Manager managerNederst2 = new Manager(collectionClerk2);
		Manager managerNederst3 = new Manager(collectionClerk3);
		
		collectionManager1.addAll(Arrays.asList(managerNederst1,managerNederst2));
		collectionManager2.add(managerNederst3);
		
		Manager managerMid1 = new Manager(collectionManager1);
		Manager managerMid2 = new Manager(collectionManager2);
		
		collectionManagerTop.addAll(Arrays.asList(managerMid1, managerMid2));
		
		Manager managerOver = new Manager(collectionManagerTop);
		
		// Bot manager-effektivitet
		managerNederst1.doCalculations((x, y) -> x*y, 1, 2);
		managerNederst1.doCalculations((x, y) -> x*y, 2, 2);
		System.out.println("bottom manager:");
		System.out.println("Resources: " + managerNederst1.getResourceCount());
		System.out.println("Tasks:" + managerNederst1.getTaskCount());
		
		// Top manager-effektivitet
		managerOver.doCalculations((x, y) -> x*y, 1, 2);
		managerOver.doCalculations((x, y) -> x*y, 2, 2);
		System.out.println("\nTop manager:");
		System.out.println("Resources:" + managerOver.getResourceCount());
		System.out.println("Tasks:" + managerOver.getTaskCount());
	}
	
}
