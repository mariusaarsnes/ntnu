package Oving7;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Printer {
	
	private Map<Employee, List<String>> map = new HashMap<Employee, List<String>>();
	
	public void printDocument(String document, Employee employee) {
		if (map.containsKey(employee)) {
			map.get(employee).add(document);
		} else {
			List<String> tempList = new ArrayList<String>();
			tempList.add(document);
			map.put(employee, tempList);
		}
		System.out.println(document);
	}
	
	public List<String> getPrintHistory(Employee employee) {
		if (map.containsKey(employee)) {
			return map.get(employee);
		}
		List<String> tempList = new ArrayList<String>();
		return tempList;
	}
}
