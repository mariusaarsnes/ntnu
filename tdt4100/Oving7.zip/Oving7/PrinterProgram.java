package Oving7;

public class PrinterProgram {

	public static void main(String[] args) {
		Printer printer = new Printer();
		Clerk clerk1 = new Clerk(printer);
		clerk1.printDocument("dokument1");
		clerk1.printDocument("dokument2");
		System.out.println((printer.getPrintHistory(clerk1).size()));
		clerk1.printDocument("dokument3");
	}

}
