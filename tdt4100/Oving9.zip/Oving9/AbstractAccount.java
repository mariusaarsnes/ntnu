package Oving9;

public abstract class AbstractAccount {
	protected double balance;
	
	public AbstractAccount() {
		balance = 0;
	}
	public void deposit(double depositAmount) {
		if (depositAmount < 0) throw new IllegalArgumentException("no!");
		else balance += depositAmount;
	}
	public void withdraw(double withdrawAmount) {
		if (withdrawAmount < 0) throw new IllegalArgumentException("no!");
		else internalWithdraw(withdrawAmount);
	}
	abstract void internalWithdraw(double withdrawAmount);
	
	public double getBalance() {
		return balance;
	}
}
