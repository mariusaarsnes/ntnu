package Oving9;

public class BSU extends SavingsAccount{
	
	protected double allowedYearlyDepositAmount;
	protected double tempBalance = 0;
	

	public BSU(Double interestrate, Double allowedYearlyDepositAmount) {
		super(interestrate);
		this.allowedYearlyDepositAmount = allowedYearlyDepositAmount;
	}
	
	@Override
	public void deposit(double depositAmount) {
		if (allowedYearlyDepositAmount < (tempBalance + depositAmount))
			throw new IllegalStateException();
		else {
			super.deposit(depositAmount);
			tempBalance += depositAmount;
		}
		
	}
	
	@Override
	public void withdraw(double withdrawAmount) {
		if (tempBalance < withdrawAmount)
			throw new IllegalStateException();
		super.withdraw(withdrawAmount);
	}
	
	@Override
	public void endYearUpdate() {
		super.endYearUpdate();
		tempBalance = 0;
	}
	
	public double getTaxDeduction() {
		return tempBalance * 0.20;
	}
}
