package Oving9;

public class CreditAccount extends AbstractAccount{

	protected double creditLine;
	
	public CreditAccount(double creditLine) {
		super();
		if (creditLine < 0) 
			throw new IllegalArgumentException("Illegal credit line.");
		this.creditLine = creditLine;
	}
	
	public void setCreditLine(double creditLine) {
		if (creditLine < 0) 
			throw new IllegalArgumentException("Illegal credit line");
		if (balance < 0 && balance < (-creditLine))
			throw new IllegalStateException
			("The credit line has so cover the negative balance");
		this.creditLine = creditLine;
	}
	public double getCreditLine() {
		return creditLine;
	}
	
	@Override
	void internalWithdraw(double withdrawAmount) {
		if ((-creditLine) > balance - withdrawAmount)
			throw new IllegalStateException("You can't withdraw that much");
		balance -= withdrawAmount;
	}

}
