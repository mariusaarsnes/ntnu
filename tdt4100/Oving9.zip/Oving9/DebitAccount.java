package Oving9;

public class DebitAccount extends AbstractAccount {

	@Override
	 void internalWithdraw(double withdrawAmount) {
		if (super.balance < withdrawAmount) 
			throw new IllegalStateException("Can't Withdraw more that you have");
		super.balance -= withdrawAmount;
	}
	
	
	
	
	
}
