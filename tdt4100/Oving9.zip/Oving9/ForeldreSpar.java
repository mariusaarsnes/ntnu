package Oving9;

public class ForeldreSpar extends SavingsAccount{

	protected int legalWithdrawTimes;
	protected int timesWithdrawed = 0;
	public ForeldreSpar(Double interestrate, int legalWithdrawTimes) {
		super(interestrate);
		this.legalWithdrawTimes = legalWithdrawTimes;
	}
	
	@Override
	public void withdraw(double withdrawAmount) {
		if (legalWithdrawTimes <= timesWithdrawed) 
			throw new IllegalStateException();
		super.withdraw(withdrawAmount);
		timesWithdrawed ++;
	}
	
	@Override
	public void endYearUpdate() {
		super.endYearUpdate();
		timesWithdrawed = 0;
	}
	
	public int getRemainingWithdrawals() {
		return legalWithdrawTimes - timesWithdrawed;
	}
}
