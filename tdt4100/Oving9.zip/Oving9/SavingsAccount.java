package Oving9;

public class SavingsAccount implements Account {
	protected double balance;
	protected double interestrate;
	
	public SavingsAccount(Double interestrate) {
		this.interestrate = interestrate;
		this.balance = 0;
	}

	@Override
	public void deposit(double depositAmount) {
		if (depositAmount < 0) 
			throw new IllegalArgumentException("Can't deposit less than 0.");
		else this.balance += depositAmount;
	}

	@Override
	public void withdraw(double withdrawAmount) {
		if (withdrawAmount < 0) 
			throw new IllegalArgumentException("Can't withdraw less than 0.");
		else if (this.balance < withdrawAmount)
			throw new IllegalStateException("Your balanse is to low.");
		else this.balance -= withdrawAmount;
	}

	@Override
	public double getBalance() {
		return this.balance;
	}
	
	public void endYearUpdate() {
		balance = balance * (1+interestrate);
	}

}
