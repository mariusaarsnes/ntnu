package Oving9;

public class SavingsAccount2 extends AbstractAccount {

	private int withdrawals;
	private double fee;
	
	public SavingsAccount2(int withdrawals, double fee) {
		super();
		this.withdrawals = withdrawals;
		this.fee = fee;
	}
	
	@Override
	void internalWithdraw(double withdrawAmount) {
		if (balance < (withdrawAmount+fee))
			throw new IllegalStateException("Can't withdraw that much.");
		if (withdrawals == 0) balance -= (fee + withdrawAmount);
		else {
			balance -= withdrawAmount;
			withdrawals --;
		}

	}
	

}
