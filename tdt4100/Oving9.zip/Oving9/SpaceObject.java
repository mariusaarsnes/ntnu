package Oving9;

import javafx.geometry.Point2D;

public class SpaceObject extends BaseSpaceObject {
	
	private Point2D speed;
	private double mass = 0;
	
	public Point2D getSpeed() {
		return speed;
	}
	
	public void setSpeed(double vx, double vy) {
		speed = new Point2D(vx,vy);
	}
	
	public void accelerate(double ax, double ay) {
		speed.add(speed.getX()+ax, speed.getY()+ay);
	}
	
	public double getMass() {
		return mass;
	}
	
	public void applyForce(double fx, double fy)throws IllegalStateException {
		if (mass == 0) throw new IllegalStateException("The mass is 0");
		speed.add(speed.getX()+(fx/mass), speed.getY()+(fy/mass));
	}

	public boolean intersects(SpaceObject other) {
		return true;
	}
}
