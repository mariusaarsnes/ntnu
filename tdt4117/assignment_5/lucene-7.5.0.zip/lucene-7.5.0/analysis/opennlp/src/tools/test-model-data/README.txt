Use small training data to create small models for unit tests.
Training data derived from Reuters corpus in very unscientific way.
Tagging done with CCG Urbana-Champaign online demos:
	http://cogcomp.cs.illinois.edu/page/demos

Run 'ant train-test-models' to generate models from training data here.
