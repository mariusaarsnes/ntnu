
import algorithm.genericAlgorithm;
import file.FileLoader;
import file.ImageWriter;
import structures.Board;
import structures.Path;

import java.util.ArrayList;

public class Main {

    // Used for running all the algorithm
    private final static String[] ALGORITHMS = new String[]{"astar", "dijkstra", "bfs"};

    // Different classes used to read in the boards, run the algorithms and saving images to visualize the results
    Board board;
    FileLoader fileLoader;
    genericAlgorithm genericAlgorithm;
    Path path;
    String file;
    ImageWriter imageWriter;


    // Initializing the program, defining variables
    public void init() {
        log("Initialising Program");
        this.fileLoader = new FileLoader();
        this.genericAlgorithm = new genericAlgorithm();
        this.imageWriter = new ImageWriter();
    }

    // Running the algorithms for all the boards
    // In stead of splitting everything into 3 parts, i have done part 3 which covers part 1 and 2 as well.
    public void run() {
        for (String algorithm : ALGORITHMS) {
            for (int j = 1; j < 3; j++) {
                for (int i = 1; i <= 4; i++) {
                    log("Shortest path for board " + j + "-" + i + " using " + algorithm);
                    file = readFile("board-" + j + "-" + i + ".txt");
                    setBoard(file);
                    runAlgorithm(algorithm);
                    saveImage("board-" + j + "-" + i + "_" + algorithm, this.path, this.board.getMatrix());

                    // These two functions were used to just print the boards with path to console.
                    // They are not needed, just for debuing purposes.
                    // They only show the path, not the openset or closed set.
                    updateBoard();
                    printBoard();
                }
            }
        }
    }

    // Saves an image of the board
    private void saveImage(String name, Path path, ArrayList matrix ) {
        this.imageWriter.writeImage(name, path, matrix);

    }
    // Reads the board from file
    private String readFile(String fileName) {
        return this.fileLoader.loadFile(fileName);

    }

    // Creates a new board
    private void setBoard(String file) {
        this.board = new Board(file);
    }

    // Runs the specified algorithm
    private void runAlgorithm(String algorithm) {
        this.path = genericAlgorithm.run(board.getGraph(), board.getStart(), board.getGoal(), algorithm);
    }

    // Used to show path in console
    private void updateBoard() {
        for (int i = 1; i < (this.path.getPath().size() - 1); i++) {
            this.path.getPath().get(i).setC('O');
        }
    }

    // Prints board to console.
    private void printBoard() {
        for (int y = 0; y < board.getMatrix().size(); y++) {
            for (int x = 0; x < board.getMatrix().get(y).size(); x++) {
                System.out.print(board.getMatrix().get(y).get(x).getC());
            }
            System.out.println();
        }

    }

    // Mostly used for debugging purposes. Not really needed anymore
    public static void log(String message) {
        System.out.println("--------------------- " + message + " ---------------------");
    }

    public static void main(String[] args) {
        Main program = new Main();

        program.init();
        program.run();


    }
}
