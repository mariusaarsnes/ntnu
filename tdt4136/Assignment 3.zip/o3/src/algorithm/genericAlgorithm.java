package algorithm;

import structures.Node;
import structures.Path;

import java.util.*;

public class genericAlgorithm {

    // Instead of making 3 different algorithms, i have made 1 that can be adapted to run as astar, dijkstra of bfs.
    public genericAlgorithm() {
    }

    public Path run(HashMap<Node, ArrayList<Node>> graph, Node start, Node end, String algorithm) {

        // Start by defining the closed set as a hashset,
        // and openset as a queue
        HashSet<Node> closedSet = new HashSet<Node>();
        Queue<Node> openSet;

        // Depending on the algorithm we want to run, a different type of queue should be used.
        // For A* and Dijkstra we want to use a PriorityQueue, comparing on different values
        // BFS does not take into account weights, so here we just use a LinkedList
        switch (algorithm){
            case "astar":
                openSet = new PriorityQueue<>(ASTAR_COMPARATOR);
                break;
            case "dijkstra":
                openSet = new PriorityQueue<>(DIJKSTRA_COMPARATOR);
                break;
            default:
                openSet = new LinkedList<>();

        }

        // current is the node the algorithm is currently at.
        // We start by adding the start-node to the openset
        Node current;
        openSet.add(start);

        while (!openSet.isEmpty()) {


            // We start by getting the first element in the queue.
            // i.e. the element with lowest F-value
            current = openSet.poll();

            // When reaching the goalnode, and using either A* or Dijkstra we end the search
            // When running bfs, we wan't to search the whole tree. If not, the second condition can be omitted.
            if (current.equals(end) && openSet instanceof PriorityQueue) {
                    return new Path(current, closedSet, openSet);
            }

            // We add the current node to the closedset to make sure that no infinite loops wil be made
            closedSet.add(current);

            for (Node neighbour : graph.get(current)) {

                // If the neighbour-node has already been checked we skip it
                if (closedSet.contains(neighbour)) {
                    continue;
                }


                // If it is a new node,
                // we need to check what the cost will be if we choose this node
                int tempWeight = current.getG() + neighbour.getWeight();

                // If the neighbour is not in the openset already, set the parent,
                // update G, and F-values.
                //If it is in the openset already, but the new path is better,
                //we should update
                if (!openSet.contains(neighbour)) {
                    neighbour.setParent(current);
                    neighbour.setG(tempWeight);
                    neighbour.setF();
                    openSet.add(neighbour);
                } else if (tempWeight < neighbour.getG()) {
                    neighbour.setParent(current);
                    neighbour.setG(tempWeight);
                    neighbour.setF();
                }
            }
        }
        return new Path(end, closedSet,openSet);
    }

    private static final Comparator<Node> ASTAR_COMPARATOR = (n1, n2) -> Integer.compare(n1.getF(),n2.getF());

    private static  final Comparator<Node> DIJKSTRA_COMPARATOR = (n1, n2) -> Integer.compare(n1.getG(),n2.getG());
}
