package file;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileLoader {

    // Reads a file, line for line.
    // This could probably be done in a better way,
    // but it is some time since i have used Java,
    // and i don't remember all the tricks.
    public static String loadFile(String fileName) {
        String line;
        String file = "";
        try {
            FileReader fileReader = new FileReader("../boards/"+fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                file = file + line + "\n";
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }
}
