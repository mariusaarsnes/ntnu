package file;

import structures.Node;
import structures.Path;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

public class ImageWriter {

    //This class is used to save images of the different boards, with the different algorithms
    public void writeImage(String name, Path path, ArrayList<ArrayList<Node>> nodes) {
        try {
            BufferedImage image = new BufferedImage(
                    nodes.get(0).size() * 50,
                    nodes.size() * 50,
                    BufferedImage.TYPE_INT_RGB);
            Graphics2D graphics2D = image.createGraphics();
            make(nodes, path, graphics2D);
            File f = new File("images/" + name + ".jpeg");
            ImageIO.write(image, "jpeg", f);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void make(ArrayList<ArrayList<Node>> nodes, Path path, Graphics g) {

        // First we draw the basic board (no path, openset or closedset)
        drawBoard(nodes, path, g);

        // Updating the image with the nodes for start and goal
        Node start = path.getPath().get(0), end = path.getPath().get(path.getPath().size() - 1);
        drawStartAndEnd(start, end, g);

        // Visualizing how the algorithm has worked.
        drawPath(path, g);
        drawClosedSet(path, g);
        drawOpenSet(path, g);

    }

    private void drawBoard(ArrayList<ArrayList<Node>> nodes, Path path, Graphics g) {
        for (int y = 0; y < nodes.size(); y++) {
            for (int x = 0; x < nodes.get(y).size(); x++) {
                // The draw method is in the nodes. Could possibly have been cleaner to have it in this class.
                nodes.get(y).get(x).draw(g);
            }
        }
    }

    // Adding correct background color to the start and end node
    private void drawStartAndEnd(Node start, Node end, Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(start.getX() * 50, start.getY() * 50, 50, 50);
        g.setColor(Color.BLACK);
        g.drawRect(start.getX() * 50, start.getY() * 50, 50, 50);

        g.setColor(Color.GREEN);
        g.fillRect(end.getX() * 50, end.getY() * 50, 50, 50);
        g.setColor(Color.BLACK);
        g.drawRect(end.getX() * 50, end.getY() * 50, 50, 50);
    }

    // Visualizing the path by draving an O on each node which is a part of the path.
    private void drawPath(Path path, Graphics g) {
        drawSymbols(path.getPath(), g, "O");
    }

    // Same as with path, just with differnt symbol
    private void drawOpenSet(Path path, Graphics g) {
        drawSymbols(path.getOpenSet(), g, "*");
    }

    // Since the closed set with include the nodes in the path,
    // we need to check for that,
    // when drawing a node, so that we don't draw and X on the path.
    private void drawClosedSet(Path path, Graphics g) {
        for (Node node : path.getClosedSet()) {
            if (!path.getPath().contains(node)) {
                drawSymbol(node, g, "X");
            }
        }

    }

    // used to draw the path and the openset
    private void drawSymbols(Collection<Node> elements, Graphics g, String symbol) {
        g.setFont(g.getFont().deriveFont(35f));
        for (Node node : elements) {
            g.drawString(symbol, node.getX() * 50 + 50 / 2 - 12, node.getY() * 50 + 50 / 2 + 12);
        }
    }

    //Used to draw the closed set
    private void drawSymbol(Node node, Graphics g, String symbol) {
        g.setFont(g.getFont().deriveFont(35f));
        g.drawString(symbol, node.getX() * 50 + 50 / 2 - 12, node.getY() * 50 + 50 / 2 + 12);
    }

}
