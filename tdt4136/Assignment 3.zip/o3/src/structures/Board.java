package structures;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;


public class Board {
    private ArrayList<ArrayList<Node>> matrix;
    private HashMap<Node, ArrayList<Node>> graph;

    public Board(String file) {
        this.matrix = new ArrayList<>();
        this.graph = new HashMap<>();
        generateMatrix(file);

        generateGraph();
        generateHValues();
    }

    // This function generates a matrix of nodes, to more easily represent and traverse the board
    // The code is not really pretty, and can be done much better but it is some time since i have written Java...
    private void generateMatrix(String file) {
        List<String> tempLines;
        ArrayList<Node> tempArray;

        tempLines = Arrays.asList(file.split("\n"));
        for (int y = 0; y < tempLines.size(); y++) {
            tempArray = new ArrayList<Node>();
            for (int x = 0; x < tempLines.get(y).length(); x++) {
                tempArray.add(new Node(x, y, tempLines.get(y).charAt(x)));
            }
            this.matrix.add(tempArray);
        }
    }


    // This function makes a graph with represented by neighbour-lists to make
    // it easier and more efficient to traverse the boards later
    private void generateGraph() {
        HashMap<Node, ArrayList<Node>> graph;

        // Values that help with adding the right neighbouring nodes,
        // and not trying to add non-valid ones.
        int top = 0, left = 0;
        int bottom = matrix.size() - 1;
        int right = matrix.get(top).size() - 1;

        for (int y = 0; y < matrix.size(); y++) {
            for (int x = 0; x < matrix.get(y).size(); x++) {

                // If the node is not walkable, we don't care about its neighbours
                if (!matrix.get(y).get(x).isWalkable()) {
                    continue;
                }

                // Initializing a new arraylist which will
                // contain all the neighbours of the current node
                this.graph.put(matrix.get(y).get(x), new ArrayList<Node>());




                // Finding all adjacent nodes coord. (ignoring diagonal neighbours)
                int[][] potentialcoords = new int[][]{
                        {y - 1, y, y + 1, y},
                        {x, x + 1, x, x - 1}
                };

                // Some checks to see if the potential neighbours are relevant or not
                for (int i = 0; i < potentialcoords[0].length; i++) {
                    if (!(left <= potentialcoords[1][i]) || !(potentialcoords[1][i] <= right)) {
                        continue;
                    }
                    if (!(top <= potentialcoords[0][i]) || !(potentialcoords[0][i] <= bottom)) {
                        continue;
                    }
                    if (!this.matrix.get(potentialcoords[0][i]).get(potentialcoords[1][i]).isWalkable()) {
                        continue;
                    }
                    this.graph.get(this.matrix.get(y).get(x))
                            .add(this.matrix.get(potentialcoords[0][i]).get(potentialcoords[1][i]));

                }
            }
        }
    }

    public ArrayList<ArrayList<Node>> getMatrix() {
        return matrix;
    }

    public HashMap<Node, ArrayList<Node>> getGraph() {
        return graph;
    }

    private void generateHValues() {
        Node end = getGoal();
        for (ArrayList<Node> nodes : this.graph.values()) {
            for (Node node : nodes) {
                node.setH(end);

            }
        }
    }

    public Node getStart() {
        return getNode('A');
    }

    public Node getGoal() {
        return getNode('B');
    }

    private Node getNode(char c) {
        for (int y = 0; y < this.matrix.size(); y++) {
            for (int x = 0; x < this.matrix.get(y).size(); x++) {
                if (this.matrix.get(y).get(x).getC() == c) {
                    return this.matrix.get(y).get(x);
                }
            }
        }
        return null;

    }
}
