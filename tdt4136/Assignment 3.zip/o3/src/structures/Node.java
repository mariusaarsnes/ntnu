package structures;

import java.awt.*;
import java.util.HashMap;

public class Node {


    // Used for coloring the board
    private static final HashMap<Character, Color> NODE_COLORS = new HashMap<>();

    static {
        NODE_COLORS.put('w', new Color(77, 77, 255));
        NODE_COLORS.put('m', new Color(166, 166, 166));
        NODE_COLORS.put('f', new Color(0, 128, 0));
        NODE_COLORS.put('g', new Color(128, 255, 128));
        NODE_COLORS.put('r', new Color(191, 128, 64));
        NODE_COLORS.put('#', new Color(0, 0, 0));
        NODE_COLORS.put('.', new Color(255, 255, 255));
    }


    private int h, x, y, f, g, weight;
    private char c;
    private Node parent = null;
    private boolean walkable = true;


    public Node(int x, int y, char c) {

        // Values used to calculate optimal path
        this.g = Integer.MAX_VALUE;

        //Position values on the board
        this.x = x;
        this.y = y;

        // Symbol of the node. which defines which type of node it is.
        this.c = c;

        setMoveCost(c);
    }

    // Private function to set he cost of moving to this node. Depending on the type of the tile.
    private void setMoveCost(char c) {
        if (c == '#') {
            this.walkable = false;
            this.weight = 100000;
        } else if (c == 'w') {
            this.weight = 100;
        } else if (c == 'm') {
            this.weight = 50;
        } else if (c == 'f') {
            this.weight = 10;
        } else if (c == 'g') {
            this.weight = 5;
        } else {
            this.weight = 1;
        }
    }

    public void setG(int g) {
        this.g = g;
    }

    public void setF() {
        this.f = this.g + this.h;
    }

    public void setC(char c) {
        this.c = c;
    }

    // Using manhattan distance to make heuristic for distance to goal node
    public void setH(Node endNode) {
        this.h = Math.abs(endNode.getX() - this.x) + Math.abs(endNode.getY() - this.y);
    }

    public void setParent(Node parent) {
        this.parent = parent;
    }

    public int getH() {
        return h;
    }

    public int getF() {
        return f;
    }

    public int getG() {
        return g;
    }

    public int getWeight() {
        return weight;
    }

    public char getC() {
        return c;
    }

    public Node getParent() {
        return this.parent;
    }

    public boolean isWalkable() {
        return walkable;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }


    // Function used to draw the node on the board
    public void draw(Graphics g) {
        g.setColor(NODE_COLORS.get(this.c));
        g.fillRect(this.x*50, this.y*50, 50, 50);
        g.setColor(Color.BLACK);
        g.drawRect(this.x *50, this.y *50, 50, 50);
    }

}
