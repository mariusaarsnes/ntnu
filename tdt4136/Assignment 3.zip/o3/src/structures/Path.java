package structures;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.Queue;

public class Path {

    private ArrayList<Node> path;
    private HashSet<Node> closedSet;
    private Queue<Node> openSet;

    public Path(Node current, HashSet<Node> closedSet, Queue<Node> openSet) {
        path = new ArrayList<>();
        buildPath(current);
        this.closedSet = closedSet;
        this.openSet = openSet;


    }

    //Iterate through every parent in the path to build it, starting at the end node.
    private void buildPath(Node current) {
        path.add(current);
        while (current.getParent() != null) {
            current = current.getParent();
            path.add(0, current);
        }
    }

    public ArrayList<Node> getPath() {
        return path;
    }

    public HashSet<Node> getClosedSet() {
        return closedSet;
    }

    public Queue<Node> getOpenSet() {
        return openSet;
    }
}
